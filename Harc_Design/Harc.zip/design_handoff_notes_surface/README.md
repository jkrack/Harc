# Handoff: Harc — Notes Surface

## Overview
This bundle is the design specification for **Notes**, a new first-class surface in Harc. Harc is a local-first macOS menu-bar app that records meetings, transcribes them locally, and turns transcripts into a searchable context engine. It already has Recordings, transcript editing, People (speaker identity), and semantic Context Packs. Notes adds the missing piece: a **Markdown-first** repository the user writes and owns, sitting next to the captured material so a note can cite a transcript chunk or a context pack as a first-class block.

The handoff covers six screens/states plus the IA, component behavior, keyboard shortcuts, and open engineering decisions.

## About the Design Files
The files in this bundle (`Notes.html`, `harc-tokens.css`) are **design references created in HTML** — a single long-scrolling design doc with each screen presented as a macOS window mock. They are not production code to copy directly.

The task is to **recreate these designs in Harc's existing codebase** using its established patterns. If Harc has an Electron/Tauri shell with React, implement there; if it is fully native (SwiftUI/AppKit), translate the structure into native sidebar+detail (`NSSplitViewController` / `NavigationSplitView`) using SF Symbols in place of the inline SVG sprite. Either way: **do not ship the HTML.** Use the existing app's design system primitives (the same components used by Recordings, Editor, Library) so Notes feels like part of the same app.

## Fidelity
**High-fidelity.** Final colors, type scale, spacing, hover/selection states, copy, and interaction model are all locked in `harc-tokens.css` (already in the codebase) and demonstrated in `Notes.html`. Recreate pixel-by-pixel using the codebase's existing component library — do not re-invent button, list-row, or sidebar primitives that already exist.

The one exception is the inline SVG icon sprite in `Notes.html`. On macOS, replace each icon with the equivalent SF Symbol (mapping table in the **Iconography** section below).

## Information Architecture

Four top-level rails — **Notes, Recordings, People, Search & Context** — as peers, not nested. Notes is at the top because it is the verb the user is most likely doing.

| Rail | Sub-sections |
|---|---|
| Notes | All · Recent · Pinned · Drafts · Archive · user Folders · Tags |
| Recordings | All · Today · This Week · Pinned · Untranscribed · By person |
| People | Directory of identities; "Me" is special |
| Search & Context | Unified search; returns chunks, not files; selection → Context Pack |

Notes are flat files (Markdown, ULID-named on disk) with YAML frontmatter for tags and links. No hard hierarchy — folders and tags are user-defined.

## Screens / Views

### F-01 · Main Workspace, Notes selected, note open
**Purpose:** The default landing view when the user clicks **Notes** in the rail. Shows the three-pane native macOS layout: sidebar / list / detail, plus an inspector on the right.

**Layout:** four columns inside the window
- **Sidebar** — `220px`, `var(--surface-1)` background, `1px solid var(--border-subtle)` right border. Contains: app toolbar with `New Note` primary button (top right of sidebar), four nav rails (Notes, Recordings, People, Search), Notes sub-sections (Recent, Pinned, Drafts, Archive), user Folders, user Tags, and a footer chip showing `● LOCAL · M3 · Neural`.
- **Note list (middle column)** — `320px`, `var(--surface-1)` background. Top toolbar (`44px`) with a filter input + sort/new icon buttons. A second toolbar strip (`30px`) shows note count + sort menu. Below: scrolling list of note rows.
- **Detail (note editor)** — flex 1, `var(--surface-2)` background. Toolbar (`44px`) with breadcrumb (`Folder / Note Title`) on the left and `Link · Tag · Share · Inspector toggle · ⋯` on the right. Body is the Markdown editor scroll area.
- **Inspector** — `320px`, `var(--surface-1)`. Three tabs: **Links · Outline · Versions**. Below: sections for Linked recordings, People, Context evidence, Backlinks.

**Note row** (`note-row`): vertical stack with `.nr-top` (title 13px / 600 + relative time 10.5px mono), `.nr-snippet` (12px secondary, 2-line clamp), `.nr-meta` (10px mono colored chips: rec=amber, ppl=green, ctx=blue). Selected row uses `var(--selection)` (slate, not the accent color) with a 3px leading edge in `var(--selection-edge)` (accent).

**Editor body** (`ed-body`):
- Title — 28px / 600 / -0.02em
- Meta line under title — pills for `recording`, `people` (with stacked avatars), `tags`, `+ Add`
- Body — 15px / 1.7 line-height, `var(--ink-primary)`
- Headings (H1 22, H2 17, H3 15) with grey `## ` prefix shown when caret is on the line
- `[[wikilinks]]` — accent color, dashed underline; amber if unresolved
- Inline `code` — mono, `var(--surface-3)` background, accent foreground

**Context callout** (`.ctx-callout`) is a first-class block, not a blockquote:
- Background `oklch(22% 0.04 252 / 0.5)`, border `oklch(40% 0.08 252 / 0.4)`, **left border 2px in `var(--accent)`**
- Header strip with mic icon + `CONTEXT · TRANSCRIPT CHUNK` label + timecode
- Verbatim quote in body
- Source row with speaker (bold), recording title, and `Open transcript →` link
- Carries the recording id + timecode + speaker + verbatim text — dragging copies the citation, not just the text. Single tap-target plays from that timecode.

### F-02 · Empty state
**Purpose:** First-run, or after Archive-all. The middle pane is empty. The detail pane teaches the three ways to start a note.

- Sidebar identical to F-01 with all counts at 0; sub-sections muted (`var(--ink-quaternary)`).
- Middle column shows a small mono label `NO NOTES YET` and a one-line hint.
- Detail pane shows a centered card (max 480px):
  - **Empty glyph** 64×64, rounded 14px, with the document icon. Background is a subtle `linear-gradient(135deg, oklch(28% 0.04 252), oklch(20% 0.03 252))` with an accent-tinted shadow.
  - Title `Write your first note` — 22px / 600
  - Subtext explaining notes are **durable**, written by the user, and Markdown
  - Two actions: primary `New Note` (`btn-prim`, accent) and quiet `Search to start from context` (`btn-quiet`, `var(--surface-3)`)
  - "Three ways to start" panel — keyboard shortcuts as kbd chips

Copy: never use marketing language. The empty state is instructive ("Write your first note"), not aspirational.

### F-03 · Markdown editor (writing mode)
**Purpose:** Head-down writing. The note list is hidden so the user has more horizontal room. Inspector remains.

- **Layout collapses to two columns**: sidebar replaced by the note's own toolbar (`Inspector toggle` icon on the far left toggles list back on); 1fr editor; 320px inspector.
- Toolbar adds a **Read / Edit toggle** segmented control and an explicit `From recording…` action (⌘⇧R) to attach a recording mid-edit.
- Save indicator chrome pill: `✓ Saved · 0:01 ago` in the window chrome bar.
- Body shows live Markdown: heading syntax (`### `) is dimmed mono and visible only when caret is on the line. Slash-command stub (`/ type a slash command — link, recording, person, context…`) at the bottom of the body.
- Inspector shows a **Wikilinks** section with resolved (default color) and unresolved (amber) entries. Unresolved click-to-create.
- Inspector includes a primary CTA `Insert context pack…` for inline pack insertion.

### F-04 · Recording detail · create or link a note
**Purpose:** Double-clicking a recording row in the Recordings rail opens the transcript editor. From here the user must be able to create a note that is pre-linked to this recording, or link an existing note.

- **Header** (24px padding) — recording title, meta line (`Date · Duration · Speakers · stacked avatars · Tags`), `Export · Copy for prompt · ⋯` actions.
- **Player row** — accent play circle (36px), waveform fill (110 bars, 20% played), timecode `3:42 / 18:46`.
- **Transcript pane** — speaker-grouped utterances: 96px meta column (color-coded speaker name + timecode) + body column (13.5px / 1.7). Search-highlighted matches use `<mark>` with accent-tinted background and accent-colored underline.
- **Inspector — Linked notes section is the hero.** When notes exist, they render as `linked-note-card` (title, 2-line snippet, mono meta `Xm ago · N cite`). When none exist, render the `empty-linked` dashed-border card with two buttons:
  - `New note from this recording` (primary accent, `btn-prim`)
  - `Link an existing note…` (quiet)
- The new-note action creates a note with the recording pre-linked, title pre-filled with the recording's date+speakers, and the cursor in the body.

### F-05 · Search & Context results
**Purpose:** ⌘⇧K opens unified search. Returns ranked **chunks** (sentences/short paragraphs) across notes and transcripts, not files.

- **Search hero** (24px padding) — large input with magnifier icon, scope chip (`All sources`), `⌘⇧K` kbd. Below: filter chips (All sources / Notes / Transcripts / When · Last 30 days / People · Sean, Lyssa / + Add filter).
- **Results** in two groups: **Top context** (selected, highlighted with accent border + inset accent shadow) and **More results** (default).
- Each result card:
  - Top row: source pill (`Recording` amber / `Note` blue), timestamp/title, relevance score with a mini bar
  - Quote with `<mark>`-highlighted matches
  - Attribution (speaker name in `var(--ink-secondary)` + source)
  - Action row separated by 1px top border: `Selected ✓ / Add to pack ＋`, `Play timecode`, `Copy quote`, `Open recording / Open note`
- **Sticky pack footer** at the bottom of the detail pane:
  - Stack: `3 chunks selected · ~840 tokens` + sub line `Sean · Michelle · 1:1 note · spans Apr 18 → Apr 20`
  - Three buttons: `Copy Context` (⌘⇧C), `Insert into Note…` (⌘⇧I), `Save as Note` (⌘⇧S, primary accent)

A **Context Pack** is the saved selection. Visually distinct from a note: purple `PACK` badge (`badge-kind.pack`) in lists; in the sidebar under "Saved packs"; pinkish chrome in the search row when displayed. **Save as Note is one-way** — once a pack is saved as a note and edited, it cannot demote back.

### F-06 · Person detail
**Purpose:** Pre-meeting prep. Shows a person's notes, recordings, and verbatim mentions.

- **Header** — 56px circular avatar with initial, name (22px / 600), meta line (`Aliases · Voice fingerprint · First heard · Total speech`), `Edit` and primary `New note about Michelle` actions.
- **Body** is a **two-column grid** (50/50, 18px gap):
  - **Left column**: `Notes (8)` cards followed by `Recordings (11)` cards. Each card has a kind badge (`NOTE` blue / `PACK` purple / `RECORDING` neutral), title, snippet, mono meta line.
  - **Right column**: `Mentions (14)` — quotes where someone *else* said the person's name. Each `mention-card` shows the quote with `<mark>` on the name (green-tinted, distinct from search highlighting) and an attribution row with speaker + source pill (amber for transcript, blue for note). Below: `Topics talked about` as filter chips (with counts).

This split — what *they* wrote/recorded vs what *others* said about them — is the core insight of the People view.

## Interactions & Behavior

### Entry points for New Note
All four routes land in the same editor with appropriate priming:
1. Sidebar/toolbar `New Note` button → blank, focus on title.
2. **⌘N** anywhere → blank, no priming.
3. **⌘⇧N** from a recording → blank with the recording pre-linked, title pre-filled (`<date> — <speakers>`), cursor in body.
4. **⌘⇧S** from search → "Save as Note" — body is empty, frontmatter contains every selected chunk as a `ctx-callout` block, plus `derived_from: pack/<id>`.

### Editor
- Live Markdown — heading syntax (`# `, `## `, `### `) visible while caret is inside the line, hidden otherwise. No preview toggle inside Edit mode; a Read/Edit segmented control switches the whole pane.
- `[[wikilinks]]` autocomplete against people, notes, recordings. Unresolved links are amber and clickable to create or merge.
- `/` opens slash actions: link recording, insert person, insert context pack, quote transcript, todo, code block.
- Auto-save on debounce; chrome pill shows `✓ Saved · Ns ago`. Versions tab in inspector lists prior saves.

### Linking note ↔ recording
- Bidirectional. Source of truth is the note's frontmatter `recordings: [<ulid>]`. Recording's inspector reads from this index and shows the join.
- From a note: ⌘L → "Link recording…" → fuzzy picker.
- From a recording: inspector "New note from this recording" creates and pre-links in one step.

### Context-pack callout
- Rendered as a single block with a left accent border and a tap-target that opens the recording at the cited timecode.
- Drag-and-drop copies the **citation** (recording id + timecode + speaker + quote), not just the text — so dragging into a different note carries the full link.

### Durable vs generated content
This distinction is enforced visually everywhere:
- Notes carry a blue `NOTE` badge or no badge.
- Generated artifacts (Context Packs, draft summaries) carry a purple `PACK` badge or amber `DRAFT` badge.
- When a pack is saved as a note, the badge flips to `NOTE` and the file gains `derived_from: pack/<id>` in frontmatter.

### Selection / hover
- Row hover: `background: var(--surface-3)` for sidebar items, `var(--surface-2)` for note rows.
- Row selected: `background: var(--selection)` (slate `oklch(42% 0.05 252)`), text inverts to `var(--selection-ink)` (white), 3px leading edge in `var(--selection-edge)` (accent). **Selection color is intentionally different from the accent** — slate background + accent edge — to keep selection legible without screaming.
- Sidebar nav `aria-current="true"`: `background: var(--accent-soft)` (`oklch(66% 0.17 252 / 0.16)`) with an inset 1px ring `oklch(66% 0.17 252 / 0.25)`. Icon turns accent color.

### Animations / motion
Use the tokens from `harc-tokens.css`:
- `--motion-state: 90ms` for hover/press (background, color)
- `--motion-overlay: 140ms` for menus, toasts, inspector tabs
- `--motion-view: 240ms` for modal swaps and pane reveals
- All ease `cubic-bezier(0.2, 0.7, 0.2, 1)`

## State Management

Per-note state:
- `id` (ULID), `title`, `body` (Markdown source), `frontmatter` (`tags`, `recordings`, `people`, `derived_from`)
- `created_at`, `updated_at`, `pinned`, `archived`, `folder_path`
- `dirty` flag for the auto-save debouncer

App state:
- Active rail (`notes` | `recordings` | `people` | `search`)
- Selected note id; selected recording id
- Inspector visible (per-rail toggle, persisted)
- Editor mode (`edit` | `read`)
- Pack-builder selection set (chunk ids) — global, survives navigation so the user can build across queries
- Search query, filter set, sort

Persistence:
- Notes are `.md` files with YAML frontmatter in the user's vault folder (default `~/Library/Harc/notes/`).
- Recording links and people links live in frontmatter — not a separate database, so users can move files between machines.
- Search index is rebuilt on save; full-text + semantic.

## Design Tokens
All tokens are already defined in `harc-tokens.css` (included in this bundle). Reference, do not redefine:

**Surfaces** (warm-black, elevation = tone shift)
| Token | Value |
|---|---|
| `--surface-0` | `#0a0c0f` (app background) |
| `--surface-1` | `#10141a` (sidebar, rail) |
| `--surface-2` | `#161b22` (main content, card) |
| `--surface-3` | `#1d242d` (hover, raised control) |
| `--surface-4` | `#252e39` (pressed) |

**Borders**: `--border-subtle: #1c232b`, `--border-strong: #2a333e`

**Ink** (4 roles): `--ink-primary #e8ecf1`, `--ink-secondary #9aa4b1`, `--ink-tertiary #6b7380`, `--ink-quaternary #4a515b`

**Accent**:
- `--accent: oklch(66% 0.17 252)` (interaction, play, link)
- `--accent-hover: oklch(72% 0.17 252)`
- `--accent-soft: oklch(66% 0.17 252 / 0.16)` (selected nav background)
- `--selection: oklch(42% 0.05 252)` (slate row selection — **not** accent)
- `--selection-edge: oklch(66% 0.17 252)` (accent leading edge on selected row)

**Semantic**: `--success oklch(72% 0.14 150)`, `--warning oklch(78% 0.13 75)`, `--danger oklch(66% 0.19 25)`, `--live oklch(70% 0.19 25)`

**Type scale** — Inter for sans, JetBrains Mono for mono. Six roles: `--type-display 28`, `--type-title 17`, `--type-subtitle 15`, `--type-body 13`, `--type-meta 12`, `--type-mono-sm 12`, `--type-mono-xs 10.5`. Line heights: tight 1.2 / snug 1.4 / normal 1.55 / loose 1.7.

**Spacing** (4-based, 6 stops): 2, 4, 8, 12, 16, 24, 32, 48 px

**Radii**: sm 4 (pills/tags) · md 6 (buttons/inputs) · lg 8 (cards) · xl 12 (tray/modal)

**Shadows** — only on floating UI: `--shadow-menu`, `--shadow-modal`, `--shadow-tray`

**Layout**: `--row-h 44`, `--rail-w 340`, `--sidebar-w 208`, `--tray-w 380`. (Notes uses 220 / 320 / 320 — slightly wider sidebar and right inspector than the Recordings rail; document this if you generalize.)

## Iconography
The HTML uses an inline SVG sprite. On macOS, replace each with the equivalent **SF Symbol**:

| Sprite id | SF Symbol | Use |
|---|---|---|
| `i-note` | `note.text` | Notes rail, note rows |
| `i-mic` | `mic` | Recordings rail, transcript citations |
| `i-people` | `person.2` | People rail |
| `i-search` | `magnifyingglass` | Search rail, filter inputs |
| `i-tag` | `tag` | Tag pills |
| `i-pin` | `pin.fill` | Pinned indicator |
| `i-plus` | `plus` | New / add |
| `i-link` | `link` | Wikilink, link action |
| `i-sidebar` | `sidebar.right` / `sidebar.left` | Inspector toggle |
| `i-folder` | `folder` | Folders |
| `i-clock` | `clock` | Recent / Today |
| `i-archive` | `archivebox` | Archive |
| `i-play` | `play.fill` | Player |
| `i-sparkle` | `sparkles` | Context / semantic match |
| `i-copy` | `doc.on.doc` | Copy quote |
| `i-arrow-down` | `arrow.down.to.line` | Insert into note |
| `i-save-note` | `square.and.pencil` | Save as note / new note |
| `i-check` | `checkmark` | Selected / saved |
| `i-share` | `square.and.arrow.up` | Share / Export |
| `i-info` | `info.circle` | Info |
| `i-more` | `ellipsis` | Overflow menu |
| `i-back` | `chevron.left` | Back |
| `i-fwd` | `chevron.right` | Forward / breadcrumb sep |

## Labels & Copy

Verb-first, short. Generated content is named by what it **is**, not how it was made — never "Generate AI summary".

- Toolbar: `New Note · Link · Tag · From recording · Edit / Read · Inspector`
- Search results: `Copy Context · Insert into Note · Save as Note`
- Recording inspector: `New note from this recording · Link an existing note…`
- Empty state: "Write your first note" (not "Get started")
- Status pill: `idle · whisper-lg-v3` / `transcribing 23%` / `transcribed locally`

## Keyboard Shortcuts

| Action | Keys |
|---|---|
| New Note | ⌘N |
| New Note from current recording | ⌘⇧N |
| Open Search & Context | ⌘⇧K |
| Quick filter (current list) | / |
| Link a note / recording / person | ⌘L |
| Tag | ⌘T |
| Pin / Unpin | ⌘⇧P |
| Toggle inspector | ⌘0 |
| Copy selected context | ⌘⇧C |
| Insert context into note | ⌘⇧I |
| Save selection as Note | ⌘⇧S |
| Open transcript at citation | ↵ on a `.ctx-callout` |

## Open Engineering Decisions

1. **R1 — Where do notes live on disk?** Recommend default vault `~/Library/Harc/notes/` with an Advanced setting to relocate (Obsidian-style). Plain `.md` + YAML frontmatter so users can edit outside the app.
2. **R2 — Citation drift after transcript edits.** Recommend a snapshot quote stored in the note + a "transcript changed" marker on the citation that lets the user re-pull. Do not live-bind.
3. **R3 — Pack → Note conversion.** Recommend one-way. Once user-edited, it is a note forever. Frontmatter `derived_from: pack/<id>` preserved as provenance.
4. **R4 — Identity merging on `[[wikilink]]` create.** Today the picker offers "create new" only. Add a "merge into existing" picker on click — required before People view ships.
5. **R5 — Quick-capture in the menu-bar tray.** Recommend post-v0.6, after main Notes UI lands. Don't fragment New-Note entry points until the core flow is stable.
6. **R6 — Search index scope.** Recommend notes indexed by default; surface an `Indexing… 3 of 142` pill in the chrome on first launch.

## Files in this bundle
- `Notes.html` — single-document design with all 6 frames + IA + behavior + risks. Uses `harc-tokens.css`.
- `harc-tokens.css` — the existing Harc design system tokens (colors, type, spacing, radii, motion). **Do not duplicate** — reference the in-codebase version of these tokens; this copy is included so the HTML renders standalone.
- `README.md` — this document.

## How to use this handoff
1. Open `Notes.html` in a browser. Scroll. Each frame is labelled `F-01` through `F-06` with a description; intersperse with the IA, behavior, shortcuts, and risk sections.
2. Cross-reference each frame with the matching section in this README.
3. Implement in the existing Harc shell. Reuse Library window's existing sidebar/list/detail primitives — Notes should look like a sibling of Recordings, not a new app.
4. Resolve the six **Open Engineering Decisions** with the design owner before implementation begins.
