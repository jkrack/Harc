# Handoff: HarcMobile Record Screen Refresh

## Overview
Refresh of the mobile Record tab (idle + recording states) in `HarcMobileApp/`. Goals: make the capture blob read as the primary tappable control, remove release-engineering copy from the UI, collapse duplicated transfer status into one line, reserve amber for genuinely blocked states, and reduce the screen from a status dashboard to a recording tool.

## About the Design Files
`Harc Mobile.dc.html` (screens 07–09) is a **design reference created in HTML** — a prototype showing intended look and behavior, not production code. The task is to **recreate these designs in the existing SwiftUI codebase** (`HarcMobileCaptureExperience.swift`, `HarcMobileRootView.swift`), reusing the existing `HarcMobileOrganicCaptureCore`, palette, and coordinator states.

## Fidelity
High-fidelity for layout, hierarchy, copy, and state logic. Colors in the HTML are iOS-dark-mode approximations — keep the existing `HarcMobilePalette` and system materials; do not port hex values where a palette color exists.

## Screens

### 07 — Record, idle, pending transfers
- **Header** (replaces the large "Harc" title + shield button):
  - Left: "Record" — `.title2.weight(.bold)` (22pt equivalent).
  - Right: host pill — capsule, `.thinMaterial`-style background, 1px hairline border; 8pt status dot (green = connected, amber = unreachable, gray = unpaired) + host display name in `.caption`/secondary. Tapping navigates to the Host tab. The shield icon moves to the Host tab.
- **Center (vertically centered)**:
  - Existing `HarcMobileOrganicCaptureCore` blob, 190pt, unchanged rendering (keep animation, audio reactivity, reduce-motion behavior).
  - Below it: **"Tap to record"** — `.title3.weight(.semibold)` (20pt), primary. This replaces "Ready to record locally".
  - One subline: **"Records to protected storage on this iPhone"** — `.footnote`, secondary. Delete the two-line paragraph (it repeated "protected copy" three times across the screen).
- **Pending card (conditional — only when recordings await transfer)**: one rounded card (radius 14, card background, hairline border) with iPhone glyph in a 34pt circle, title **"2 recordings safe on this iPhone"** (`.subheadline.semibold`), subline **"Transfers paused · they move to {Host} when ready"** (`.caption`, secondary), chevron → local recordings list. This card **replaces** all of: the 3-row status board, the orange "Lossless codec qualification required" banner, the codec explainer paragraph, and the "On This iPhone" row.
- **Removed entirely from user-facing UI**: "Transfer unavailable in this build", "CAF+ALAC versus FLAC must pass the physical-iPhone release gate". Move codec-gate detail to a diagnostics screen under the Host tab if needed.

### 08 — Record, idle, all caught up
Same as 07 but the pending card is hidden. In its place (under the subline, 8pt gap): green checkmark glyph (14pt) + **"All recordings verified on {Host}"** (`.caption`, secondary). Content block is vertically centered.

### 09 — Recording
- Top (centered): pulsing 11pt red dot + **"Recording"** in coral, `.subheadline.semibold`.
- Center stack, 24pt gaps: elapsed timer — monospaced digits, ~56pt, ultralight/thin weight; blob at 200pt in its existing recording (coral) style with white 34pt rounded-square stop glyph; **"Tap to stop"** (`.subheadline.semibold`) + **"Protected on this iPhone"** (`.footnote`, secondary).
- Tab bar: Record tab label swaps to the live elapsed time in coral while recording.

## Interactions & Behavior
- Blob remains the start/stop button (existing accessibility labels/identifiers stay). Add a pressed affordance: scale to 0.96, ~120ms ease-out.
- Idle→recording: blob palette crossfades indigo/violet→coral (existing style switch), label crossfades "Tap to record"→timer stack.
- Pending card appears/disappears with a standard opacity+move transition.
- Host pill states map from `HarcMobileHostHealthStatus`: connected → green dot + name; checking → gray dot + "Checking…"; unavailable → amber dot + name; unpaired → gray dot + "Pair a Host" (navigates to Host tab pairing).

## State Mapping (HarcMobileCaptureStatusPresentation.transfer)
Single status line/card replaces the board row + banner:
- `codecQualificationRequired`, `idle` w/ pending, `retryNeeded`, `waitingForPairing` → **neutral** pending card (not amber). Copy pattern: "{n} recordings safe on this iPhone" / contextual subline.
- `encoding`/`connecting`/`uploading`/`backgroundScheduled` → pending card subline becomes the in-flight text ("Sending to {Host}…") with small spinner.
- `idle` all-verified / `uploaded` → caught-up line (screen 08).
- `securityBlocked` → the **only** amber/critical treatment: card tinted caution with "Transfer paused — security review required".
- Library row is removed from this screen; the Library tab owns library status.

## Design Tokens (HTML reference values)
- Backgrounds: screen #0C0C0D, card #1C1C1D; hairline rgba(255,255,255,0.08) — use system dark equivalents.
- Text: primary rgba(255,255,255,0.92), secondary 0.55, tertiary 0.33.
- Accents: keep `HarcMobilePalette` (coral, indigo, violet, cyan, success, amber). Blue #0A84FF = system tint.
- Radii: card 14, pill/dot 999. Spacing: 20pt screen margins, 12–15pt card padding, 10pt card gaps.

## Assets
No new assets. All glyphs are SF Symbols already in use (`mic.fill`, `stop.fill`, `checkmark`, `iphone`, `chevron.right`).

## Files
- `Harc Mobile.dc.html` — screens 07 (pending), 08 (caught up), 09 (recording); screens 01–06 are an earlier broader exploration, not part of this handoff scope.
- Source files to modify: `HarcMobileApp/HarcMobileCaptureExperience.swift` (hero, status board, presentation copy), `HarcMobileApp/HarcMobileRootView.swift` (header/title, tab label).
- Note: UI tests assert on removed strings ("Ready to record locally" in `HarcMobileUITests/…ReleaseReadinessUITests.swift`, `…AppStoreScreenshotUITests.swift`) — update them to "Tap to record".
